package com.example.Hengki.Responsi170

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {

    val nama    = arrayOf<String>("Burger",
        "Cake",
        "Potato",
        "Pizza",
        "Spageti",
        "Risoles",
        "Roti Bakar",
        "Rujak Cingur",
        "Sate",
        "Soup")

    val imageId = arrayOf<Int>(
        R.drawable.burger,
        R.drawable.cake,
        R.drawable.kentang,
        R.drawable.piza,
        R.drawable.spag,
        R.drawable.risoles,
        R.drawable.rotibkr,
        R.drawable.rujak,
        R.drawable.sate,
        R.drawable.sop

    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val myListAdapter = ListAdapter(this,nama,imageId)
        lview.adapter = myListAdapter

        val bundle = intent.extras
        val userBro = bundle?.get("usr2").toString()
        val namaBro = bundle?.get("nama2").toString()
        val nimBro = bundle?.get("nim2").toString()
        val passBro = bundle?.get("pss2").toString()

        tombol.setOnClickListener{
            intent = Intent(this, AccountActivity::class.java)
            intent.putExtra("nim2",namaBro)
            intent.putExtra("nama2",nimBro)
            intent.putExtra("usr2",userBro)
            intent.putExtra("pss2",passBro)
            startActivity(intent)
        }

        lview.setOnItemClickListener(){adapterView, view, position, id ->
            val itemAtPos = adapterView.getItemAtPosition(position)
            val itemIdAtPos = adapterView.getItemIdAtPosition(position)

            var a = Integer.parseInt(itemIdAtPos.toString())
            var pr = a+1

            if (a.equals(0)){
                Toast.makeText(this, "Burger $itemAtPos , Harga = Rp. 25.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(1)){
                Toast.makeText(this, "Cake $itemAtPos , Harga = Rp. 20.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(2)){
                Toast.makeText(this, "Potato $itemAtPos , Harga = Rp. 15.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(3)){
                Toast.makeText(this, "Pizza $itemAtPos , Harga = Rp. 50.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(4)){
                Toast.makeText(this, "Spageti $itemAtPos , Harga = Rp. 25.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(5)){
                Toast.makeText(this, "Risoles $itemAtPos , Harga = Rp. 2500,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(6)){
                Toast.makeText(this, "Roti Bakar $itemAtPos , Harga = Rp. 10.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(7)){
                Toast.makeText(this, "Rujak cingur $itemAtPos , Harga = Rp. 25.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(8)){
                Toast.makeText(this, "Sate $itemAtPos , Harga = Rp. 15.000,00", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(9)){
                Toast.makeText(this, "Soup $itemAtPos , Harga = Rp. 17.000,00", Toast.LENGTH_LONG).show()
            }

            else {
                Toast.makeText(this, "Pilihan Habis", Toast.LENGTH_LONG).show()
            }
        }
    }
}
